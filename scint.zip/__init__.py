"""Top-level package for scint."""

__author__ = """Tim Kaechle"""
__email__ = "timothy.kaechle@me.com"
__version__ = "0.0.9"
